﻿using System.Net.Http;
using System.Threading.Tasks;
using MyCookBook.Models;
using System.Text.Json;

public class RecipeService
{
    private readonly HttpClient _httpClient;

    // Constructor to inject HttpClient
    public RecipeService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    // Method to fetch the recipe from the API using System.Text.Json
    public async Task<Recipe> GetRecipeAsync()
    {
        // Make the GET request to the API
        var response = await _httpClient.GetStringAsync("https://localhost:5001/api/recipe/GetRecipe");

        // Deserialize the JSON response into a Recipe object
        var recipe = JsonSerializer.Deserialize<Recipe>(response); // Using System.Text.Json here

        // Return the recipe object
        return recipe;
    }
}