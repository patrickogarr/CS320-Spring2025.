using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Models;
using System.Collections.Generic;
using System.Linq;

namespace MyCookBookApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RecipeController : ControllerBase
    {
        private static readonly List<Recipe> Recipes = new()
        {
            new Recipe { Id = 1, Name = "Pasta", Ingredients = new List<string> { "Pasta", "Tomato Sauce" }, Steps = "Boil pasta and mix with sauce." },
            new Recipe { Id = 2, Name = "Salad", Ingredients = new List<string> { "Lettuce", "Tomatoes", "Cucumber" }, Steps = "Mix all ingredients." }
        };

        [HttpGet]
        public IActionResult GetRecipes()
        {
            return Ok(Recipes);
        }

        [HttpGet("{id}")]
        public IActionResult GetRecipeById(int id)
        {
            var recipe = Recipes.Find(r => r.Id == id);
            if (recipe == null)
            {
                return NotFound("Recipe not found.");
            }
            return Ok(recipe);
        }

        [HttpPost]
        public IActionResult AddRecipe([FromBody] Recipe recipe)
        {
            if (recipe == null)
            {
                return BadRequest("Invalid recipe data.");
            }

            recipe.Id = Recipes.Count + 1;
            Recipes.Add(recipe);
            return CreatedAtAction(nameof(GetRecipeById), new { id = recipe.Id }, recipe);
        }

        [HttpGet("search")]
        public IActionResult SearchRecipes([FromQuery] string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return BadRequest("Search term is required.");
            }

            var searchResults = Recipes.Where(r =>
                r.Name.Contains(searchTerm, System.StringComparison.OrdinalIgnoreCase) ||
                r.Ingredients.Any(i => i.Contains(searchTerm, System.StringComparison.OrdinalIgnoreCase))
            ).ToList();

            return Ok(searchResults);
        }
    }
}


