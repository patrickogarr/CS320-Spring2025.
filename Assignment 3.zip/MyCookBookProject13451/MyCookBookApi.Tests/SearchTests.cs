﻿using Microsoft.AspNetCore.Mvc.Testing;
using MyCookBookApi;
using MyCookBookApi.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

public class RecipeControllerTests : IClassFixture<WebApplicationFactory<MyCookBookApi.Program>>
{
    private readonly HttpClient _client;

    public RecipeControllerTests(WebApplicationFactory<MyCookBookApi.Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task SearchRecipes_Returns_Recipes_Containing_Query()
    {
        var searchRequest = new RecipeSearchRequest
        {
            Query = "Tomato"
        };
        var content = new StringContent(JsonConvert.SerializeObject(searchRequest), Encoding.UTF8, "application/json");

        var response = await _client.PostAsync("/api/recipe/search", content);

        response.EnsureSuccessStatusCode();

        var responseContent = await response.Content.ReadAsStringAsync();
        var recipes = JsonConvert.DeserializeObject<List<Recipe>>(responseContent);

        Assert.NotEmpty(recipes);
        Assert.Contains(recipes, r => r.Name.Contains("Tomato") || r.Ingredients.Exists(i => i.Contains("Tomato")));
    }

    [Fact]
    public async Task SearchRecipes_Returns_NotFound_When_No_Match()
    {
        var searchRequest = new RecipeSearchRequest
        {
            Query = "NonExistentIngredient"
        };
        var content = new StringContent(JsonConvert.SerializeObject(searchRequest), Encoding.UTF8, "application/json");

        var response = await _client.PostAsync("/api/recipe/search", content);

        Assert.Equal(404, (int)response.StatusCode);
    }

    [Fact]
    public async Task SearchRecipes_Returns_BadRequest_When_Query_Is_Empty()
    {
        var searchRequest = new RecipeSearchRequest
        {
            Query = ""
        };
        var content = new StringContent(JsonConvert.SerializeObject(searchRequest), Encoding.UTF8, "application/json");

        var response = await _client.PostAsync("/api/recipe/search", content);

        Assert.Equal(400, (int)response.StatusCode);
    }
}
