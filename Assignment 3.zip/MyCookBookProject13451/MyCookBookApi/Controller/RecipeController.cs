using Microsoft.AspNetCore.Mvc;
using MyCookBookApi.Models;
using System.Linq;

namespace MyCookBookApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RecipeController : ControllerBase
    {
        private static readonly List<Recipe> Recipes = new()
        {
            new Recipe
            {
                Name = "Pasta",
                Ingredients = new List<string> { "Pasta", "Tomato Sauce" },
                Steps = "Boil pasta."
            },
            new Recipe
            {
                Name = "Salad",
                Ingredients = new List<string> { "Lettuce", "Tomatoes", "Cucumber" },
                Steps = "Mix all ingredients."
            },
            new Recipe
            {
                Name = "Omelette",
                Ingredients = new List<string> { "Eggs", "Cheese", "Salt", "Pepper" },
                Steps = "Whisk eggs and cook in a pan."
            }
        };

        [HttpGet]
        public IActionResult GetRecipes()
        {
            return Ok(Recipes);
        }

        [HttpPost("search")]
        public IActionResult SearchRecipes([FromBody] RecipeSearchRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Query))
            {
                return BadRequest("Search query cannot be empty.");
            }

            var results = Recipes
                .Where(r => r.Name.Contains(request.Query, StringComparison.OrdinalIgnoreCase) ||
                            r.Ingredients.Any(i => i.Contains(request.Query, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            if (!results.Any())
            {
                return NotFound("No matching recipes found.");
            }

            return Ok(results);
        }
    }
}