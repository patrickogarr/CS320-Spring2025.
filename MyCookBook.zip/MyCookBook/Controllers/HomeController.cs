using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MyCookBook.Models;

namespace MyCookBook.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View("HomePage");
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult About()
        {
            return View("About");
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Search(string searchQuery)
        {
            var sampleData = new List<string>
            {
                "food"
            };
            var searchResults = sampleData
                .FindAll(item => item.Contains(searchQuery, System.StringComparison.OrdinalIgnoreCase));
            ViewBag.SearchResults = searchResults;

            return View("HomePage");
        } 
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
