//using Microsoft.AspNetCore.Mvc;
//using MyCookBookApi.Models;
//[ApiController]
//[Route("api/[controller]")]
//public class RecipeController : ControllerBase
//{
//  [HttpGet]
//public IActionResult GetRecipes()
//{
//  return Ok(new List<Recipe>
//    {
//new Recipe { Name = "Pasta", Ingredients = new
//List<string> { "Pasta", "Tomato Sauce" }, Steps = "Boil pasta." },
//new Recipe { Name = "Salad", Ingredients = new
//List<string> { "Lettuce", "Tomatoes" }, Steps = "Mix all ingredients."
//}
//});

//    }
//}
using Microsoft.AspNetCore.Mvc;
using MyCookBookApi.Models;
[ApiController]
[Route("api/[controller]")]
public class RecipeController : ControllerBase
{
    private static readonly List<Recipe> Recipes = new List<Recipe>
{
new Recipe { Name = "Pasta", Ingredients = new List<string> { "Pasta",
"Tomato Sauce" }, Steps = "Boil pasta and mix with sauce." },
new Recipe { Name = "Salad", Ingredients = new List<string> { "Lettuce",
"Tomatoes", "Cucumbers" }, Steps = "Chop and mix ingredients." }
};
    [HttpGet]
    public IActionResult GetRecipes()
    {
        return Ok(Recipes);
    }
}