﻿using Microsoft.AspNetCore.Mvc;
using MyCookBook.Models;
using System.Threading.Tasks;

public class RecipeController : Controller
{
    private readonly RecipeService _recipeService;

    // Inject RecipeService
    public RecipeController(RecipeService recipeService)
    {
        _recipeService = recipeService;
    }

    // Action to get the recipe and return it to the view
    public async Task<IActionResult> Index()
    {
        var recipe = await _recipeService.GetRecipeAsync(); // Fetch recipe data from API
        return View(recipe); // Pass the recipe object to the view
    }
}