﻿namespace MyCookBookApi.Models
{
    public class RecipeSearchRequest
    {
        public string Query { get; set; }
    }
}
