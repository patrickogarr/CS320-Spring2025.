﻿using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Models;
using MyCookBookApp.Services;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace MyCookBookApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly RecipeService _recipeService;

        public HomeController(RecipeService recipeService)
        {
            _recipeService = recipeService ?? throw new ArgumentNullException(nameof(recipeService));
        }

        public async Task<IActionResult> Index()
        {
            Console.WriteLine("✅ HomeController.Index() called.");

            var recipes = await _recipeService.GetRecipesAsync();
            if (recipes == null)
            {
                Console.WriteLine("❌ RecipeService returned null!");
                recipes = new List<Recipe>(); 
            }
            else
            {
                Console.WriteLine($"✅ Fetched {recipes.Count} recipes.");
            }

            return View(recipes);
        }
    }
}


