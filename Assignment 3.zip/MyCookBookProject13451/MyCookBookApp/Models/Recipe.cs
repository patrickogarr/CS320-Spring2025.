namespace MyCookBookApp.Models
{
    public class Recipe
    {
        public int Id { get; set; } 
        public string Name { get; set; }
        public List<string> Ingredients { get; set; } = new List<string>(); 
        public string Steps { get; set; }
    }
}