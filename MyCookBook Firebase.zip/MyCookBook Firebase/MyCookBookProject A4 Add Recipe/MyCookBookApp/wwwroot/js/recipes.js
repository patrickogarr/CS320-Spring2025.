document.addEventListener("DOMContentLoaded", function () {
    const BASE_URL = `${window.location.origin}/Recipe`;  // Dynamically set base URL
    let selectedCategories = [];
    let selectedEditCategories = [];

    // Define a mapping of category numbers to their text values
    const categoryMapping = {
        0: "Breakfast",
        1: "Lunch",
        2: "Dinner",
        3: "Dessert",
        4: "Snack",
        5: "Vegan",
        6: "Vegetarian",
        7: "GlutenFree",
        8: "Keto",
        9: "LowCarb",
        10: "HighProtein"
    };

    fetchRecipes();

    // Handle category selection
    document.querySelectorAll("#categoryList .dropdown-item").forEach(item => {
        item.addEventListener("click", function (event) {
            event.preventDefault();
            let categoryValue = parseInt(this.getAttribute("data-value"), 10);
            if (selectedCategories.includes(categoryValue)) {
                selectedCategories = selectedCategories.filter(c => c !== categoryValue);
            } else {
                selectedCategories.push(categoryValue);
            }

            // Update button text
            document.getElementById("categoryDropdown").innerText =
                selectedCategories.length > 0 ? selectedCategories.map(id => document.querySelector(`[data-value="${id}"]`).innerText).join(", ") : "Select Categories";

            // Update hidden input
            document.getElementById("categories").value = JSON.stringify(selectedCategories);
        });
    });

    // Handle category selection for edit modal
    document.querySelectorAll("#editCategoryList .dropdown-item").forEach(item => {
        item.addEventListener("click", function (event) {
            event.preventDefault();
            let categoryValue = parseInt(this.getAttribute("data-value"), 10);
            if (selectedEditCategories.includes(categoryValue)) {
                selectedEditCategories = selectedEditCategories.filter(c => c !== categoryValue);
            } else {
                selectedEditCategories.push(categoryValue);
            }

            // Update button text
            document.getElementById("editCategoryDropdown").innerText =
                selectedEditCategories.length > 0 ? selectedEditCategories.map(id => document.querySelector(`#editCategoryList [data-value="${id}"]`).innerText).join(", ") : "Select Categories";

            // Update hidden input
            document.getElementById("editCategories").value = JSON.stringify(selectedEditCategories);
        });
    });

    // Handle Update Recipe event
    document.getElementById("updateRecipe").addEventListener("click", function (event) {
        event.preventDefault();
        updateRecipe();
    });

    // Edit Recipe - Fetch Recipe Details and Show Modal
    window.editRecipe = function (recipeId) {
        fetch(`${BASE_URL}/${recipeId}`)
            .then(response => response.json())
            .then(recipe => {
                if (!recipe) {
                    console.error("Recipe not found");
                    return;
                }

                // Assign `recipeId` before opening the modal
                document.getElementById("editRecipeId").value = recipe.recipeId;
                document.getElementById("editRecipeName").value = recipe.name;
                document.getElementById("editTagLine").value = recipe.tagLine || "";
                document.getElementById("editSummary").value = recipe.summary || "";
                document.getElementById("editIngredients").value = Array.isArray(recipe.ingredients) ? recipe.ingredients.join(", ") : "";
                document.getElementById("editInstructions").value = Array.isArray(recipe.instructions) ? recipe.instructions.join("\n") : "";

                const selectedCategories = Array.isArray(recipe.categories) ? recipe.categories : [];
                let selectedCategoryNames = selectedCategories.map(catId => categoryMapping[catId] || "No Category");

                // Check each category option and mark selected if present in selectedCategories
                const categoryOptions = document.querySelectorAll("#editCategoryList .dropdown-item");
                categoryOptions.forEach(option => {
                    let categoryValue = parseInt(option.getAttribute("data-value"), 10);
                    if (selectedCategories.includes(categoryValue)) {
                        option.classList.add("active");
                    } else {
                        option.classList.remove("active");
                    }
                });

                // Update dropdown button text with selected categories
                document.getElementById("editCategoryDropdown").innerText =
                    selectedCategoryNames.length > 0 ? selectedCategoryNames.join(", ") : "Select Categories";

                // Store selected categories in hidden input field
                document.getElementById("editCategories").value = JSON.stringify(selectedCategories);

                // Show the modal
                var editRecipeModal = new bootstrap.Modal(document.getElementById('editRecipeModal'));
                editRecipeModal.show();
            })
            .catch(error => console.error("Error fetching recipe:", error));
    };

    // Update Recipe function
    window.updateRecipe = function () {
        let recipe = {
            recipeId: document.getElementById("editRecipeId").value.trim(),
            name: document.getElementById("editRecipeName").value.trim(),
            tagLine: document.getElementById("editTagLine").value.trim(),
            summary: document.getElementById("editSummary").value.trim(),
            ingredients: document.getElementById("editIngredients").value.split(",").map(i => i.trim()),
            instructions: document.getElementById("editInstructions").value.split("\n").map(i => i.trim()),
            categories: JSON.parse(document.getElementById("editCategories").value || "[]"),
            media: []
        };

        const recipeId = recipe.recipeId;
        if (!recipeId) {
            console.error("No recipe ID found!");
            alert("Recipe ID is missing. Cannot update.");
            return;
        }

        fetch(`${BASE_URL}/Edit/${recipeId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(recipe)
        })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(`Error ${response.status}: ${text}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                alert("Recipe updated successfully!");
                let modal = bootstrap.Modal.getInstance(document.getElementById('editRecipeModal'));
                modal.hide();
                setTimeout(() => location.reload(), 500);
            })
            .catch(error => {
                console.error("Error updating recipe:", error);
                alert("Failed to update recipe: " + error.message);
            });
    };

    // Open the Add Recipe Modal
    document.getElementById("addRecipeBtn")?.addEventListener("click", function () {
        document.getElementById("addRecipeForm").reset();
        $('#addRecipeModal').modal('show');
    });

    // Delete Recipe
    window.deleteRecipe = function (recipeId) {
        if (!confirm("Are you sure you want to delete this recipe?")) return;
        fetch(`${BASE_URL}/Delete/${recipeId}`, {
            method: "DELETE"
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    fetchRecipes();
                } else {
                    alert("Failed to delete recipe: " + data.message);
                }
            })
            .catch(error => console.error("Error deleting recipe:", error));
    };

    // Save Recipe function
    document.getElementById("saveRecipe").addEventListener("click", function (event) {
        event.preventDefault();

        let recipe = {
            recipeId: "NewRecipe_Only",
            name: document.getElementById("recipeName").value.trim(),
            tagLine: document.getElementById("tagLine").value.trim(),
            summary: document.getElementById("summary").value.trim(),
            ingredients: document.getElementById("ingredients").value.split(",").map(i => i.trim()),
            instructions: document.getElementById("instructions").value.split("\n").map(i => i.trim()),
            categories: JSON.parse(document.getElementById("categories").value || "[]"),
            media: []
        };

        fetch(`${BASE_URL}/Add`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(recipe)
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    let modal = new bootstrap.Modal(document.getElementById('addRecipeModal'));
                    modal.hide();
                    setTimeout(() => location.reload(), 500);
                } else {
                    alert("Failed to add recipe: " + data.message);
                }
            })
            .catch(error => console.error("Error adding recipe:", error));
    });

    // Fetch all recipes
    function fetchRecipes() {
        fetch(`${BASE_URL}/GetAll`)
            .then(response => response.json())
            .then(recipes => displayRecipes(recipes))
            .catch(error => console.error("Fetch error:", error));
    }

    // Search for recipes
    window.searchRecipes = function () {
        let keyword = document.getElementById("searchInput").value.trim();
        if (!keyword) {
            fetchRecipes();
            return;
        }

        let searchRequest = { keyword: keyword, categories: [] };

        fetch(`${BASE_URL}/Search`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(searchRequest)
        })
            .then(response => response.json())
            .then(recipes => displayRecipes(recipes))
            .catch(error => console.error("Search error:", error));
    };

    // Handle Enter key press for search
    window.handleEnter = function (event) {
        if (event.key === "Enter") {
            searchRecipes();
        }
    };

    // Show or hide the clear search button
    window.toggleClearButton = function () {
        let searchInput = document.getElementById("searchInput");
        let clearButton = document.getElementById("clearSearch");
        clearButton.style.display = searchInput.value.trim() ? "block" : "none";
    };

    // Clear search and reload all recipes
    window.clearSearch = function () {
        document.getElementById("searchInput").value = "";
        document.getElementById("clearSearch").style.display = "none";
        fetchRecipes();
    };

    // Display recipes dynamically
    function displayRecipes(recipes) {
        let cardContainer = document.getElementById("recipeCards");
        cardContainer.innerHTML = "";

        recipes.forEach(recipe => {
            let imageUrl = recipe.media?.[0]?.url || "placeholder.jpg";
            let categoriesText = (recipe.categories || []).map(catId => categoryMapping[catId] || "No Category").join(" | ");

            let card = `<div class="mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="card-title mb-0">${recipe.name}</h5>
                                <p class="text-muted mb-2">${recipe.tagLine || ""}</p>
                            </div>
                            <div>
                                <button class="btn btn-warning btn-sm" onclick="editRecipe('${recipe.recipeId}')">Edit</button>
                            </div>
                            <div>
                                <button class="btn btn-warning btn-sm" onclick="deleteRecipe('${recipe.recipeId}')">Delete</button>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <h6>Chef's Note</h6>
                                <p class="card-text">${recipe.summary || "No summary available."}</p>
                                <h6>Ingredients</h6>
                                <p class="card-text">${recipe.ingredients ? recipe.ingredients.join(", ") : "N/A"}</p>
                            </div>
                            <div class="col-md-6">
                                <h6>Instructions</h6>
                                <p class="card-text">${recipe.instructions ? recipe.instructions.join("<br>") : "N/A"}</p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-muted text-left" style="font-size: 0.85rem;">
                        <b>Categories: </b>${categoriesText}
                    </div>
                </div>
            </div>`;

            cardContainer.innerHTML += card;
        });
    }
});
