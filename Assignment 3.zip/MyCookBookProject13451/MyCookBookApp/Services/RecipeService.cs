﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using MyCookBookApp.Models;
using Newtonsoft.Json;

namespace MyCookBookApp.Services
{
    public class RecipeService
    {
        private readonly HttpClient _httpClient;

        public RecipeService(HttpClient httpClient)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        }

        public async Task<List<Recipe>> GetRecipesAsync()
        {
            try
            {
                Console.WriteLine("📡 Calling API: http://localhost:5147/api/recipe");
                var response = await _httpClient.GetAsync("http://localhost:5147/api/recipe");

                if (!response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"❌ API returned {response.StatusCode}");
                    return new List<Recipe>(); 
                }

                var json = await response.Content.ReadAsStringAsync();
                var recipes = JsonConvert.DeserializeObject<List<Recipe>>(json);
                Console.WriteLine($"✅ API returned {recipes?.Count ?? 0} recipes.");
                return recipes ?? new List<Recipe>(); 
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Exception fetching recipes: {ex.Message}");
                return new List<Recipe>(); 
            }
        }
    }
}

