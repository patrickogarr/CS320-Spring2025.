using Microsoft.AspNetCore.Mvc;
using MyCookBookApp.Services;
using System.Threading.Tasks;

namespace MyCookBookApp.Controllers
{
    public class RecipeController : Controller
    {
        private readonly RecipeService _recipeService;

        public RecipeController(RecipeService RecipeService)
        {
            _recipeService = RecipeService;
        }

        // Search action
        public async Task<IActionResult> SearchRecipes(string query) //Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
            {
                return RedirectToAction("Index");
            }

            var recipes = await _recipeService.SearchRecipesAsync(query);
            return View("Index", recipes);
        }
    }
}
