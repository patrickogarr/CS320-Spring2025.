namespace MyCookBookApp.Models
{
    public enum CategoryType
    {
        Breakfast, Lunch, Dinner, Dessert, Snack, Vegan, Vegetarian, 
        GlutenFree, Keto, LowCarb, HighProtein
    }
}
